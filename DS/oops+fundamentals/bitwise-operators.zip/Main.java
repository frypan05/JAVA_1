/*           conditinal statements: 
              1. decision  amaking statements
2.  jumping statements
3. iterative statements
*/






public class Main
{
	public static void main(String[] args) {
	    int a=10,b=3;
	    int c=(a>b)?a:b;
	   
		System.out.println(" "+c);
		
	}
}
