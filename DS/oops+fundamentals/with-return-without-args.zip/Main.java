import java.util.Scanner;
public class Main
{
    int method1()             //contains local variable and can't be accessed outside the method
    {
        System.out.println("Instance method");
        System.out.println("With return type without args");
        Scanner sc = new Scanner(System.in);    //parameterized constructor
        System.out.println("Enter a value to return: ");
        int n = sc.nextInt();
        return n;
        
    }
	public static void main(String[] args)
	{
	    Main m = new Main();
	    int variable = m.method1();
	    System.out.println("Recieved value: "+variable);
		System.out.println("Hello World");
	}
}
