/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
  public static void main (String[]args)
  {
    Scanner sc = new Scanner (System.in);
    int a = sc.nextInt ();

    if (a < 40)
        System.out.println ("Grade D");
    else if (40 < a < 60)
        System.out.println ("Grade C");
    else if (60 < a < 80)
        System.out.println ("Grade B");
    else if (80 < a < 90)
        System.out.println ("Grade A");
    else if (90 < a < 100)
        System.out.println ("Grade O");
    else
        System.out.println ("enter valid marks");


  }
}
