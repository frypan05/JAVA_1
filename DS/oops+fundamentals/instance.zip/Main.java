                    /*NOTES*/
//class is a blueprint of an object
//static means same for all the objects; the engine for a car
//instance local to that object; colour of that car differs
//tasks are represented by methods
//individual object can perform multiple tasks
//in class, you can use multiple methods
//every object has its own properties
//every individual object has its own properties
//runtime input:
//compiletime input: 


public class Main  
{
  short s = 125;		// instance variable
  static int k = 123;		//static 
  public static void main (String[]args)
  {
      byte b = -128;
      static int j=23;
      System.out.println (" b :" + b + " k :" + k);
      System.out.println (" Hello World");
      Main obj = new Main ();
      System.out.println (" obj.s: " + obj.s);
      System.out.println (" Main.k: " + Main.k);
      System.out.println (" obj.k: " + obj.k);
      System.out.println(" j: "+j);
		

  }
}
