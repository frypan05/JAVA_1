


/*                              NOTES    OPERATERS
Unary                     Binary                   Terinery             Special
uses 1 operand           Relational:
[++a] PreIncrement       (<,<=,>,>=,==,!=)
[a++] PostIncrement      Arithemetic:
[--a] PreDecrement       (+,-,*,/,%)
[a--] Postdecrement      Logical:
                         (&&,||,!)
                         Bitwise:






*/

import java.util.Scanner;
public class Main
{
  void fun ()
  {

  }
  void sun ()
  {

  }
  public static void main (String[]args)
  {
    byte b;
    Scanner sc = new Scanner (System.in);	//parameterised constructor
    b = sc.nextByte ();
    System.out.println (" byte b: " + b);	//
    System.out.println (" ENTER THE BYTE DATA ");
    
    short s = sc.nextShort ();
    System.out.println (" Short s: " + s);
    System.out.println (" Enter the String data: ");
    
    int i = sc.nextInt ();
    System.out.println (" Integer: " + i);
    System.out.println (" Enter the Integer data: ");
    
    long l = sc.nextLong ();
    System.out.println (" Long l: " + l);
    System.out.println (" Enter the float data: ");
    
    float v = sc.nextFloat ();
    System.out.println (" float v: " + v);
    System.out.println (" Enter the double data: ");
    
    double d = sc.nextDouble ();
    System.out.println (" double d: " + d);
    System.out.println (" Enter the char data: ");
    
    char ch = sc.next ().charAt (0);
    System.out.println (" char ch: " + ch);
    System.out.println (" Enter the string: ");
    
    String str = sc.next ();
    System.out.println (" string str: " + str);

  }
}
