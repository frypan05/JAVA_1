
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc= new Scanner (System.in);
	    int n=sc.nextInt();   //4321
	             //4+3+2+1 == 1+2+3+4
	    int sum=0;
	    while(n!=0)//4321!=0 ,321!=0 , 21!=0 , 1!=0 , 0=0
	    {
	        int rem=n%10; //4 , 3 , 2 , 1
	        sum=sum*10+rem; //0+4=4*10+3=43*10+2=432*10+1=4321
	        n=n/10; //123 , 23 , 3 , 0
	        
	        
	    }
		System.out.println(sum+" ");
	}
}
