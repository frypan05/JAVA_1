/*


            12 * 12 -> 144
            144->441
            sqrt 441 -> 21
            21 -> 12
            so 12 is an Adam Number

*/

