/* && || ! */
public class Main
{
	public static void main(String[] args) {
	    int a=10,b=11,c=12;
	    System.out.println(a<b && c>b && b<c);
	    System.out.println(b>c || a>b || b<c);
	    System.out.println(!(b>c || a>b || b<c));
	}
}
