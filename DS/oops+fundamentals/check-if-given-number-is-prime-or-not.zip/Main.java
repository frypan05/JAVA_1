import java.util.Scanner;  
class Main
{
    static boolean CheckPrime(int data)//data=n
    {
        int i;
        for (i=2;i<=data/2;i++)
        {
            if (data%i==0)
                return false;
        }
        return true;
    }
    public static void main (String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the data to check prime or not: ");
        int n = sc.nextInt();
        if (CheckPrime(n)==true)
                System.out.println("prime");
        else
            System.out.println("not prime");
        
    }
}
    