/******************************************************************************

methods:
built in methods : int, float, sqrt
user defined methods : 
1. without return without arguments
2. without return with arguments
3. with return without arguments
4. with return with arguments


two ways:
static 
instance

*******************************************************************************/

