import java.util.Scanner;
class Main
{
    static boolean checkAutomorphic(int n)
    {
        int square=n*n;
        while(n!=0)
        {
            if (n%10!==square%10)
                 return false;
            n=n/10;
            square=square/10;
        }
        return true;
    }
	public static void main(String[] args) 
	{
	    Scanner sc = new Scanner(System.in);
		System.out.println("Enter the data: ");
		int n=sc.nextInt();
		if (checkAutomorphic(n))
		   System.out.println("Automorphic Number");
		else
		   System.out.println("Not Automorphic Number");
	}
}
