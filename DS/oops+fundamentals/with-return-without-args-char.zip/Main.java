/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
    int method1()             //contains local variable and can't be accessed outside the method
    {
        System.out.println("static method");
        System.out.println("With return type without args");
        Scanner sc = new Scanner(System.in);    //parameterized constructor
        System.out.println("Enter a int to return: ");
        int n = sc.nextInt();
        return n;
        
    }
	static char method2()
	{
	    System.out.println("static method");
        System.out.println("With return type without args");
        Scanner sc = new Scanner(System.in);    //parameterized constructor
        System.out.println("Enter a char to return: ");
        char n = sc.next().charAt(0);
        return n;
	}
	public static void main(String[] args)
	{
	    
	}
}
