import java.util.Scanner;
public class Main                         //with return type with args
{
    boolean CheckEven(int value) //value=n 
    {
        if(value%2==0)
            return true;
        else
            return false;
    }
    static boolean CheckEven2(int value) //value=n
    {
        
    }
	public static void main(String[] args) {
		Main m = new Main ();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the data: ");
		int n=sc.nextInt();
		boolean ans = m.CheckEven(n);
		System.out.println(ans);
		int data = sc.nextInt();
		ans = CheckEven2(data);
		System.out.println(ans);
		System.out.println(CheckEven2(sc.nextInt());
	}
}
