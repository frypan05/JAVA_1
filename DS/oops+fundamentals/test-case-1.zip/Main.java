//input: 6  output: 1 3 6 10 15 21


import java.util.Scanner;
public class Main
{
  public static void main (String[]args)
  {
    Scanner sc = new Scanner (System.in);
    int n = sc.nextInt ();
    int sum=0;
    for (int i = 1; i <= n; i++)
    {
        sum=sum+i;
    
        System.out.print(sum + " ");}
  }
}




