/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
  public static void main (String[]args)
  {
    int a = 10, b = 20, c, d;
      System.out.println ("a: " + a);
      System.out.println ("b: " + b);
      //a = a + a;
      //b = 2 * b - a - 10;
      a=a+b;
      b=a-b;
      a=a-b;
      System.out.println ("a after swap: " + a);
      System.out.println ("b after swap: " + b);
  }
}

