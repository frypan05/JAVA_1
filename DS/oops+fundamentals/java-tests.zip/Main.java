

public class Main
{
    short s=125; //instance variable
    static int k=123; //static variable
	public static void main(String[] args) { //static method
		byte b=-128;
		System.out.println("Hello World");
	}
}
