import java.util.Scanner;  
class Main
{
    static boolean CheckPrime(int data)//data=n
    {
        int i;
        for (i=2;i<=data/2;i++)
        {
            if (data%i==0)
                return false;
        }
        return true;
    }
    void Nprime( int n)
    {
        int count = 0;
        int i=2;
        while (count<n)
        {
            if(CheckPrime(i))
            {
              System.out.println(i+" ");
              count++;
            }
            i++;
        }
    }
    public static void main (String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the data to print prime or not: ");
        int n = sc.nextInt();
        Main m = new Main();
        m.Nprime(n);
        
    }
}
    