import java.util.Scanner;
public class Main
{
    void method1(char ch) //void has no specific data type, thus no output.
    {
        System.out.println("instance method");
        System.out.println("Without return with args");
        System.out.println("args ch: "+ch);
        return;
    }
    static void method2(float v,String str)
    {
        System.out.println("Static method");
        System.out.println("without return with args");
        System.out.println("args v: "+v+" str : "+str);
        return;
    }
	public static void main(String[] args) {
		System.out.println("Main");
		method2(34.56f,"cse-ds");
		Main.method2(123.456f,"HEHE");
		Main m = new Main();
		Scanner sc = new Scanner(System.in);
		m.method1(sc.next().charAt(0));
		float v =sc. nextFloat();
		String s=sc.next();
		m.method2(v,s);
	}
}
