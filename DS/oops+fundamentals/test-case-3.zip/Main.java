//input: 5  output: 1 4 10 20 35




import java.util.Scanner;
public class Main
{
  public static void main (String[]args)
  {
    Scanner sc = new Scanner (System.in);
    int n = sc.nextInt ();
    int sum=0;
    int prev=0;
    for (int i = 1; i <= n; i++)
    {
        sum=sum+i;
        prev=prev+sum;
    
        System.out.print(prev + " ");}
  }
}