/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
  public static void main (String[]args)
  {
    Scanner sc = new Scanner (System.in);
    int option = sc.nextInt ();
    switch (option)		/*case number */
    {
        case 1:System.out.println ("case 1");
	           System.out.println ("case 1 stmt 2");
	           break;
	    case 2:System.out.println ("case 2");
	           System.out.println ("case 2 stmt 2");
	           break;
	    case 3:System.out.println ("case 3");
	           System.out.println ("case 3 stmt 2");
	           break;
      }
  }
}
  
  
  
  
  
  
  
  