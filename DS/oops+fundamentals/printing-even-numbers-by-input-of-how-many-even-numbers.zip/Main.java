/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
  public static void main (String[]args)
  {
    Scanner sc = new Scanner (System.in);
    int n = sc.nextInt ();
    for (int i = 1; i <= n; i++)
        System.out.println (2 * i + " ");
      System.out.println (" 2nd approach");
    for (int i = 2; i <= 2 * n; i = i + 2);
      System.out.println ("\n 3rd approach \n");
    for (int i = 1; i <= 2 * n; i++)
      {
	if (i % 2 == 0)
	  System.out.println (i + " ");
      }
  }
}
